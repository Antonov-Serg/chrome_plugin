chrome-plugin

https://developers.google.com/identity/protocols/OAuth2ForDevices

https://developers.google.com/adwords/api/docs/guides/call-structure?hl=ru

https://developers.google.com/adwords/api/docs/guides/authentication?hl=ru
